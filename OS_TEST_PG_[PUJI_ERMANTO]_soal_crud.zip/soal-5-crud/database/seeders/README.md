echo jalankan (ketik command dibawah) : 
\n echo composer install
\n echo php artisan ui vue
\n echo npm install
\n echo npm run watch